package com.github.sarxos.webcam.util;

public interface Initializable {

	void initialize();

	void teardown();

}
