/**
 * 
 */
/**
 * @author kerr
 *
 */
package us.sosia.video.stream.agent.ui;