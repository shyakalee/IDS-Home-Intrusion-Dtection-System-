In this directory you can find some more or less complicated examples
of how Webcam Capture can be used with additional 3'rd party frameworks.

Enjoy!
