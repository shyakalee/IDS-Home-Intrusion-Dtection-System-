package com.github.sarxos.webcam.ds.mjpeg.tcp;

public class TcpConnectionRegistrar {

	public static void register() {
		Handler.register();
	}
}
